<template>
    <div>
        <nav>
            <ul class="list-unstyled d-flex justify-content-evenly">
                <li>
                    <router-link to="/">Home</router-link>
                </li>
                <li>
                    <router-link to="/create">Create team</router-link>
                </li>
                <li>
                    <router-link to="/edit">Edit Team</router-link>
                </li>
            </ul>
        </nav>
    </div>     
</template>

<script>

</script>
