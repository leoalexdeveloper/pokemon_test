export default{
    localstorage:{
        pokemonList: 'pokemonList'
    },
    pokemons:{
        limit:12,
        limitSlot:4
    }
}