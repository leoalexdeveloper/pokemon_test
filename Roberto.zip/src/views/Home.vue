<template>
    <div>
        
        {{'Olá Home'}}
    </div>
</template>

<script>

</script>
